`timescale 1ns / 1ps

module testbench;

    // Inputs
    reg         clk;
    reg         mult_begin;
    reg [31:0]  mult_op1;
    reg [31:0]  mult_op2;

    // Outputs
    wire [63:0] product;
    wire        mult_end;

    // 用于统计周期数
    integer cycle_cnt;

    // Instantiate the Unit Under Test (UUT)
    multiply uut (
        .clk       (clk),
        .mult_begin(mult_begin),
        .mult_op1  (mult_op1),
        .mult_op2  (mult_op2),
        .product   (product),
        .mult_end  (mult_end)
    );

    // 10ns 时钟周期
    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    // 单组测试任务
    task run_case;
        input signed [31:0] a;
        input signed [31:0] b;
        reg   signed [63:0] expect;
        begin
            expect = a * b;
            cycle_cnt = 0;

            mult_op1   = a;
            mult_op2   = b;
            mult_begin = 1'b1;

            while (!mult_end) begin
                @(posedge clk);
                cycle_cnt = cycle_cnt + 1;
            end

            @(posedge clk);
            mult_begin = 1'b0;

            $display("--------------------------------------------------");
            $display("a       = %0d, b = %0d", a, b);
            $display("expect  = %0d, hex = 0x%h", expect, expect);
            $display("product = %0d, hex = 0x%h", $signed(product), product);
            $display("cycles  = %0d", cycle_cnt);

            if ($signed(product) !== expect) begin
                $display("ERROR: result mismatch!");
            end
            else begin
                $display("PASS");
            end

            #20;
        end
    endtask

    initial begin
    
        mult_begin = 1'b0;
        mult_op1   = 32'd0;
        mult_op2   = 32'd0;

        #20;
        
//        第一次
          run_case(32'sd13, 32'sd11);
//        第二次
//        run_case(-32'sd13, 32'sd11);
//        第三次
//        run_case(-32'sd25, -32'sd4);

        #100;
        $finish;
    end

endmodule