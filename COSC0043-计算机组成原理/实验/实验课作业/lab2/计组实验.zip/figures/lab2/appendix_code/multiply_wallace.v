`timescale 1ns / 1ps

//**************************************************************
// > 文件名: multiply_wallace.v
// > 描述  : 华莱士树（压缩树）优化版乘法器
// > 说明  : 尽量保留手册参考 multiply.v 的接口风格
// >         主要变化为：
// >         1. 不再采用逐拍移位累加的迭代乘法
// >         2. 改为并行生成部分积
// >         3. 使用 CSA 压缩树（Wallace Tree 风格）进行多操作数压缩
// >         4. 最终使用一次加法得到无符号绝对值乘积
// >         5. 再进行符号恢复，得到补码乘积
//**************************************************************
module multiply_wallace(
    input         clk,         // 时钟
    input         mult_begin,  // 乘法开始信号
    input  [31:0] mult_op1,    // 乘法源操作数1（补码）
    input  [31:0] mult_op2,    // 乘法源操作数2（补码）
    output [63:0] product,     // 乘积（补码）
    output        mult_end     // 乘法结束信号
);

    //==========================================================
    // 1) 运算控制
    //==========================================================
    //【修改】手册原版是"迭代乘法"，mult_end 由乘数移空决定
    //【修改】华莱士树核心为并行组合逻辑，为了兼容原显示模块，
    //         这里把结果先寄存，再将 mult_end 延后一拍输出
    reg mult_valid;
    reg mult_end_r;

    assign mult_end = mult_end_r;

    always @(posedge clk) begin
        if (!mult_begin) begin
            mult_valid <= 1'b0;
            mult_end_r <= 1'b0;
        end
        else begin
            mult_valid <= 1'b1;       //【新增】表示本次运算已经进入有效阶段
            mult_end_r <= mult_valid; //【新增】延后一拍输出结束信号，方便外围锁存结果
        end
    end

    //==========================================================
    // 2) 两个源操作数先取绝对值
    //==========================================================
    //【保留手册思路】仍然采用"先取绝对值参与运算，最后恢复符号"的方式
    wire        op1_sign;
    wire        op2_sign;
    wire [31:0] op1_absolute;
    wire [31:0] op2_absolute;

    assign op1_sign     = mult_op1[31];
    assign op2_sign     = mult_op2[31];
    assign op1_absolute = op1_sign ? (~mult_op1 + 32'd1) : mult_op1;
    assign op2_absolute = op2_sign ? (~mult_op2 + 32'd1) : mult_op2;

    //==========================================================
    // 3) CSA 压缩器函数
    //==========================================================
    //【新增】华莱士树核心：把3个操作数压缩成2个操作数
    // sum   = a ^ b ^ c
    // carry = majority(a,b,c) << 1
    function [63:0] csa_sum;
        input [63:0] a;
        input [63:0] b;
        input [63:0] c;
        begin
            csa_sum = a ^ b ^ c;
        end
    endfunction

    function [63:0] csa_carry;
        input [63:0] a;
        input [63:0] b;
        input [63:0] c;
        begin
            csa_carry = ((a & b) | (a & c) | (b & c)) << 1;
        end
    endfunction

    //==========================================================
    // 4) 部分积与压缩树中间结果
    //==========================================================
    //【新增】并行部分积
    reg [63:0] pp [0:31];

    //【新增】各级压缩树中间结果
    reg [63:0] stage1 [0:21]; // 32 -> 22
    reg [63:0] stage2 [0:14]; // 22 -> 15
    reg [63:0] stage3 [0:9 ]; // 15 -> 10
    reg [63:0] stage4 [0:6 ]; // 10 -> 7
    reg [63:0] stage5 [0:4 ]; // 7  -> 5
    reg [63:0] stage6 [0:3 ]; // 5  -> 4
    reg [63:0] stage7 [0:2 ]; // 4  -> 3

    reg [63:0] wallace_a;
    reg [63:0] wallace_b;
    reg [63:0] unsigned_product;

    integer i;

    //==========================================================
    // 5) 华莱士树（压缩树）组合逻辑
    //==========================================================
    always @(*) begin
        //------------------------------------------------------
        // 5.1 并行生成 32 个部分积
        //------------------------------------------------------
        //【新增】与迭代乘法不同，这里不再逐拍移位相加，
        //       而是一次性生成全部部分积
        for (i = 0; i < 32; i = i + 1) begin
            if (op2_absolute[i]) begin
                pp[i] = ({32'd0, op1_absolute} << i);
            end
            else begin
                pp[i] = 64'd0;
            end
        end

        //------------------------------------------------------
        // 5.2 stage1 : 32 -> 22
        //------------------------------------------------------
        stage1[ 0] = csa_sum  (pp[ 0], pp[ 1], pp[ 2]);
        stage1[ 1] = csa_carry(pp[ 0], pp[ 1], pp[ 2]);
        stage1[ 2] = csa_sum  (pp[ 3], pp[ 4], pp[ 5]);
        stage1[ 3] = csa_carry(pp[ 3], pp[ 4], pp[ 5]);
        stage1[ 4] = csa_sum  (pp[ 6], pp[ 7], pp[ 8]);
        stage1[ 5] = csa_carry(pp[ 6], pp[ 7], pp[ 8]);
        stage1[ 6] = csa_sum  (pp[ 9], pp[10], pp[11]);
        stage1[ 7] = csa_carry(pp[ 9], pp[10], pp[11]);
        stage1[ 8] = csa_sum  (pp[12], pp[13], pp[14]);
        stage1[ 9] = csa_carry(pp[12], pp[13], pp[14]);
        stage1[10] = csa_sum  (pp[15], pp[16], pp[17]);
        stage1[11] = csa_carry(pp[15], pp[16], pp[17]);
        stage1[12] = csa_sum  (pp[18], pp[19], pp[20]);
        stage1[13] = csa_carry(pp[18], pp[19], pp[20]);
        stage1[14] = csa_sum  (pp[21], pp[22], pp[23]);
        stage1[15] = csa_carry(pp[21], pp[22], pp[23]);
        stage1[16] = csa_sum  (pp[24], pp[25], pp[26]);
        stage1[17] = csa_carry(pp[24], pp[25], pp[26]);
        stage1[18] = csa_sum  (pp[27], pp[28], pp[29]);
        stage1[19] = csa_carry(pp[27], pp[28], pp[29]);
        stage1[20] = pp[30];
        stage1[21] = pp[31];

        //------------------------------------------------------
        // 5.3 stage2 : 22 -> 15
        //------------------------------------------------------
        stage2[ 0] = csa_sum  (stage1[ 0], stage1[ 1], stage1[ 2]);
        stage2[ 1] = csa_carry(stage1[ 0], stage1[ 1], stage1[ 2]);
        stage2[ 2] = csa_sum  (stage1[ 3], stage1[ 4], stage1[ 5]);
        stage2[ 3] = csa_carry(stage1[ 3], stage1[ 4], stage1[ 5]);
        stage2[ 4] = csa_sum  (stage1[ 6], stage1[ 7], stage1[ 8]);
        stage2[ 5] = csa_carry(stage1[ 6], stage1[ 7], stage1[ 8]);
        stage2[ 6] = csa_sum  (stage1[ 9], stage1[10], stage1[11]);
        stage2[ 7] = csa_carry(stage1[ 9], stage1[10], stage1[11]);
        stage2[ 8] = csa_sum  (stage1[12], stage1[13], stage1[14]);
        stage2[ 9] = csa_carry(stage1[12], stage1[13], stage1[14]);
        stage2[10] = csa_sum  (stage1[15], stage1[16], stage1[17]);
        stage2[11] = csa_carry(stage1[15], stage1[16], stage1[17]);
        stage2[12] = csa_sum  (stage1[18], stage1[19], stage1[20]);
        stage2[13] = csa_carry(stage1[18], stage1[19], stage1[20]);
        stage2[14] = stage1[21];

        //------------------------------------------------------
        // 5.4 stage3 : 15 -> 10
        //------------------------------------------------------
        stage3[0] = csa_sum  (stage2[ 0], stage2[ 1], stage2[ 2]);
        stage3[1] = csa_carry(stage2[ 0], stage2[ 1], stage2[ 2]);
        stage3[2] = csa_sum  (stage2[ 3], stage2[ 4], stage2[ 5]);
        stage3[3] = csa_carry(stage2[ 3], stage2[ 4], stage2[ 5]);
        stage3[4] = csa_sum  (stage2[ 6], stage2[ 7], stage2[ 8]);
        stage3[5] = csa_carry(stage2[ 6], stage2[ 7], stage2[ 8]);
        stage3[6] = csa_sum  (stage2[ 9], stage2[10], stage2[11]);
        stage3[7] = csa_carry(stage2[ 9], stage2[10], stage2[11]);
        stage3[8] = csa_sum  (stage2[12], stage2[13], stage2[14]);
        stage3[9] = csa_carry(stage2[12], stage2[13], stage2[14]);

        //------------------------------------------------------
        // 5.5 stage4 : 10 -> 7
        //------------------------------------------------------
        stage4[0] = csa_sum  (stage3[0], stage3[1], stage3[2]);
        stage4[1] = csa_carry(stage3[0], stage3[1], stage3[2]);
        stage4[2] = csa_sum  (stage3[3], stage3[4], stage3[5]);
        stage4[3] = csa_carry(stage3[3], stage3[4], stage3[5]);
        stage4[4] = csa_sum  (stage3[6], stage3[7], stage3[8]);
        stage4[5] = csa_carry(stage3[6], stage3[7], stage3[8]);
        stage4[6] = stage3[9];

        //------------------------------------------------------
        // 5.6 stage5 : 7 -> 5
        //------------------------------------------------------
        stage5[0] = csa_sum  (stage4[0], stage4[1], stage4[2]);
        stage5[1] = csa_carry(stage4[0], stage4[1], stage4[2]);
        stage5[2] = csa_sum  (stage4[3], stage4[4], stage4[5]);
        stage5[3] = csa_carry(stage4[3], stage4[4], stage4[5]);
        stage5[4] = stage4[6];

        //------------------------------------------------------
        // 5.7 stage6 : 5 -> 4
        //------------------------------------------------------
        stage6[0] = csa_sum  (stage5[0], stage5[1], stage5[2]);
        stage6[1] = csa_carry(stage5[0], stage5[1], stage5[2]);
        stage6[2] = stage5[3];
        stage6[3] = stage5[4];

        //------------------------------------------------------
        // 5.8 stage7 : 4 -> 3
        //------------------------------------------------------
        stage7[0] = csa_sum  (stage6[0], stage6[1], stage6[2]);
        stage7[1] = csa_carry(stage6[0], stage6[1], stage6[2]);
        stage7[2] = stage6[3];

        //------------------------------------------------------
        // 5.9 最后一轮压缩：3 -> 2，再做一次普通加法
        //------------------------------------------------------
        wallace_a = csa_sum  (stage7[0], stage7[1], stage7[2]);
        wallace_b = csa_carry(stage7[0], stage7[1], stage7[2]);

        //【新增】最终进位传播加法器
        unsigned_product = wallace_a + wallace_b;
    end

    //==========================================================
    // 6) 寄存无符号乘积，并恢复符号
    //==========================================================
    reg [63:0] product_temp;
    reg        product_sign;

    always @(posedge clk) begin
        if (mult_begin) begin
            //【新增】锁存华莱士树压缩后的无符号乘积
            product_temp <= unsigned_product;

            //结果符号 = 两输入符号异或
            product_sign <= op1_sign ^ op2_sign;
        end
    end

    //若结果应为负，则取反加1恢复补码
    assign product = product_sign ? (~product_temp + 64'd1) : product_temp;

endmodule