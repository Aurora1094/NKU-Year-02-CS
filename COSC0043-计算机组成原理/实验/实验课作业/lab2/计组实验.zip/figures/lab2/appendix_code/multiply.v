`timescale 1ns / 1ps
//**************************************************************
**
// > 文件名: multiply.v
// > 描述 ：乘法器模块，低效率的迭代乘法算法，使用两个乘数绝对值参与运算
// > 作者 : LOONGSON
// > 日期 : 2016-04-14
//**************************************************************
**

module multiply( // 乘法器
input clk,                // 时钟
input mult_begin,         // 乘法开始信号
input [31:0] mult_op1,    // 乘法源操作数1
input [31:0] mult_op2,    // 乘法源操作数2
output [63:0] product,    // 乘积
output mult_end           // 乘法结束信号
);

//乘法正在运算信号和结束信号
reg mult_valid;

//结束条件仍然使用"乘数移空"为结束标志
assign mult_end = mult_valid & ~(|multiplier); //乘法结束信号：乘数全0

always @(posedge clk)
begin
    if (!mult_begin || mult_end)
    begin
        mult_valid <= 1'b0;
    end
    else
    begin
        mult_valid <= 1'b1;
    end
end

//两个源操作取绝对值，正数的绝对值为其本身，负数的绝对值为取反加1
wire op1_sign;            //操作数1的符号位
wire op2_sign;            //操作数2的符号位
wire [31:0] op1_absolute; //操作数1的绝对值
wire [31:0] op2_absolute; //操作数2的绝对值
assign op1_sign = mult_op1[31];
assign op2_sign = mult_op2[31];
assign op1_absolute = op1_sign ? (~mult_op1+1) : mult_op1;
assign op2_absolute = op2_sign ? (~mult_op2+1) : mult_op2;

//加载被乘数，运算时每次左移一位
reg [63:0] multiplicand;
always @ (posedge clk)
begin
    if (mult_valid)
    begin
        //【修改】手册原版为每次左移1位：
        // multiplicand <= {multiplicand[62:0],1'b0};

        //【修改】2位乘优化：每次左移2位
        multiplicand <= {multiplicand[61:0],2'b00};
    end
    else if (mult_begin)
    begin
        //乘法开始时装载被乘数绝对值
        multiplicand <= {32'd0,op1_absolute};
    end
end

//加载乘数，运算时每次右移一位
reg [31:0] multiplier;
always @ (posedge clk)
begin
    if (mult_valid)
    begin
        //【修改】手册原版为每次右移1位：
        // multiplier <= {1'b0,multiplier[31:1]};

        //【修改后】2位乘优化：每次右移2位
        multiplier <= {2'b00,multiplier[31:2]};
    end
    else if (mult_begin)
    begin
        //乘法开始时装载乘数绝对值
        multiplier <= op2_absolute;
    end
end

// 部分积：乘数末位为1，由被乘数左移得到；乘数末位为0，部分积为0
// wire [63:0] partial_product;
// assign partial_product = multiplier[0] ? multiplicand : 64'd0;

//【删除】以上是手册原版"1位乘"的部分积生成方式，只判断 multiplier[0]
//【新增】改为"2位乘"方式，根据 multiplier[1:0] 生成 0、M、2M、3M 四种部分积
reg [63:0] partial_product;
always @(*)
begin
    case (multiplier[1:0])
        2'b00: partial_product = 64'd0;                           //【新增】加0
        2'b01: partial_product = multiplicand;                    //【新增】加1倍M
        2'b10: partial_product = (multiplicand << 1);             //【新增】加2倍M
        2'b11: partial_product = multiplicand + (multiplicand << 1); //【新增】加3倍M
        default: partial_product = 64'd0;
    endcase
end

//累加器
reg [63:0] product_temp;
always @ (posedge clk)
begin
    if (mult_valid)
    begin
        //继续累加当前部分积
        product_temp <= product_temp + partial_product;
    end
    else if (mult_begin)
    begin
        //乘法开始，乘积清零
        product_temp <= 64'd0;
    end
end

//乘法结果的符号位和乘法结果
reg product_sign;
always @ (posedge clk) // 乘积符号
begin
    if (mult_valid)
    begin
        //结果符号仍为两操作数符号异或
        product_sign <= op1_sign ^ op2_sign;
    end
end

//若乘法结果为负数，则需要对结果取反+1
assign product = product_sign ? (~product_temp+1) : product_temp;

endmodule